/**
 * This class represents the model of the table "SESSION" of the database.
 * Here the data of the user's sessions is handled.
 *
 * This class implements the Serializable interface, which means that the object can be
 * converted into a heap of bytes and can later be retrieved, making it easier for us
 * to send information through intents.
 */

package com.lavv.crossfitapp;

import java.io.Serializable;

public class Session implements Serializable{
    private int id;
    private String date_session;
    private String comment;
    private String movements;

    /**
     *
     * @param id
     * @param date_session
     * @param comment
     * @param movements
     */
    public Session(int id, String date_session, String comment, String movements) {
        this.id = id;
        this.date_session = date_session;
        this.comment = comment;
        this.movements = movements;
    }

    /**
     *
     * @return
     */
    public String getMovements() {
        return movements;
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getDate_session() {
        return date_session;
    }

    /**
     *
     * @return
     */
    public String getComment() {
        return comment;
    }

}
